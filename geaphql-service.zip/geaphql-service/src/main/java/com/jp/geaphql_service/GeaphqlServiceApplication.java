package com.jp.geaphql_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeaphqlServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeaphqlServiceApplication.class, args);
	}

}
