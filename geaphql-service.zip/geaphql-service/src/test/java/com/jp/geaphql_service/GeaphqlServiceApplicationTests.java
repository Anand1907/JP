package com.jp.geaphql_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeaphqlServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
